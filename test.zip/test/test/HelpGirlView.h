//
//  HelpGirlView.h
//  TeleStation
//
//  Created by 冯垚杰 on 2017/3/13.
//  Copyright © 2017年 huangbinbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HelpGirlViewModel;

@interface HelpGirlView : UIView

@property (nonatomic,strong) HelpGirlViewModel *model;

//- (void)show;
- (void)dismissWithFrom:(UIView *)view;

+ (instancetype)showHelpGirlAddedTo:(UIView *)view ViewModel:(HelpGirlViewModel *)model;

@end

@interface HelpGirlViewModel : NSObject

/** 图片url */
@property (nonatomic,copy) NSString *iconUrl;
/** 昵称 */
@property (nonatomic,copy) NSString *nick;
/** 签名 */
@property (nonatomic,copy) NSString *autograph;
/** 标签 */
@property (nonatomic,copy) NSString *tag;
/** 星座 */
@property (nonatomic,copy) NSString *constellation;

/** 三角形定点x位置 默认为中点 赋值时为当前界面的x坐标-本view的x坐标*/
@property (nonatomic, assign) CGFloat startX;
/** 上下左右绘制间距 默认0 */
@property (nonatomic, assign) UIEdgeInsets insets;
/** 圆角大小  默认高度的0.1倍 */
@property (nonatomic, assign) CGFloat radius;
@property (nonatomic, assign) CGRect rect;
/** 三角形高度 默认10 */
@property (nonatomic, assign) CGFloat triangleHeight;
/** 填充的背景颜色 默认白色 */
@property (nonatomic,strong) UIColor *bgColor;
/** 边框颜色 默认黄色 */
@property (nonatomic,strong) UIColor *lineColor;

@end
