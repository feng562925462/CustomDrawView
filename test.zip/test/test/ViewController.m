//
//  ViewController.m
//  test
//
//  Created by 冯垚杰 on 2017/3/12.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import "ViewController.h"
#import "CustomView.h"
#import "HelpGirlCollectionViewCell.h"
#import "HelpGirlView.h"

@interface ViewController () <UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) HelpGirlView *HGView;


@end

@implementation ViewController


#pragma mark - collectionView
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.sectionInset = UIEdgeInsetsMake(0, 10, 0, 10);
        layout.itemSize = CGSizeMake(([UIScreen mainScreen].bounds.size.width - 6 * 10)/5, ([UIScreen mainScreen].bounds.size.width - 6 * 10)/5 + 40);
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 200) collectionViewLayout:layout];
        
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        
        [_collectionView registerNib:[UINib nibWithNibName:@"HelpGirlCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"HelpGirlCollectionViewCell"];
        _collectionView.backgroundColor = [UIColor whiteColor];
        
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        
        [self.view addSubview:_collectionView];
    }
    return _collectionView;
}

#pragma mark  collectionViewDataSource -  UICollectionViewDelegateFlowLayout

/* 个数 **/
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 10;
}

#define IPHONE_WIDTH [UIScreen mainScreen].bounds.size.width

/* 选中 **/
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
    //获取cell在当前collection的位置
    CGRect cellInCollection = [collectionView convertRect:[collectionView cellForItemAtIndexPath:indexPath].frame toView:collectionView];
    
    //获取cell在当前屏幕的位置
    CGRect cellInSuperview = [collectionView convertRect:cellInCollection toView:self.view];
    
    HelpGirlViewModel *model = [[HelpGirlViewModel alloc] init];
    // 赋值
    model.radius = 10;

//    model.iconUrl = headImgUrl;
    model.nick = @"关关";
    model.autograph = @"在我心中曾经有一个个梦";
    model.tag = @"吃货、女神、丑八怪";
    model.constellation = @"王八座";
    
    CGFloat x = 0;
    if (cellInSuperview.origin.x > IPHONE_WIDTH * 0.5) {
        x = IPHONE_WIDTH * 0.3 - 12;
    } else {
        x = 12;
    }
    model.startX = cellInSuperview.origin.x + CGRectGetWidth(cellInSuperview)/2 - x;
    
    model.rect = CGRectMake( x , CGRectGetMaxY(cellInSuperview), IPHONE_WIDTH * 0.7, IPHONE_WIDTH * 0.7/2);
    _HGView = [HelpGirlView showHelpGirlAddedTo:nil ViewModel:model];

    
//    _HGView = [[HelpGirlView alloc] initWithFrame:CGRectMake( x , CGRectGetMaxY(cellInSuperview), IPHONE_WIDTH * 0.7, IPHONE_WIDTH * 0.7/2) ViewModel:model];
//    [_HGView show];

}

/* cell设置 **/
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HelpGirlCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HelpGirlCollectionViewCell" forIndexPath:indexPath];
    
    return cell;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    [self collectionView];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [_HGView dismissWithFrom:nil];
}
@end
