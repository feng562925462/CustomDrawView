//
//  HelpGirlView.m
//  TeleStation
//
//  Created by 冯垚杰 on 2017/3/13.
//  Copyright © 2017年 huangbinbin. All rights reserved.
//

#import "HelpGirlView.h"

static HelpGirlView *oldView = nil;

// 计算两条线直接的角度
#define radiansToDegrees(x) (180.0 * x / M_PI)
CGFloat angleBetweenLines(CGPoint line1Start, CGPoint line1End, CGPoint line2Start, CGPoint line2End) {
    
    CGFloat a = line1End.x - line1Start.x;
    CGFloat b = line1End.y - line1Start.y;
    CGFloat c = line2End.x - line2Start.x;
    CGFloat d = line2End.y - line2Start.y;
    
    CGFloat rads = acos(((a*c) + (b*d)) / ((sqrt(a*a + b*b)) * (sqrt(c*c + d*d))));
    
    return radiansToDegrees(rads);
}

//设置颜色
#define HEXCOLOR(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface HelpGirlView ()

@property (nonatomic,strong) UIImageView *iconImageView;  // 人物图片
@property (nonatomic,strong) UILabel *nickLabel; // 昵称
@property (nonatomic,strong) UILabel *constellationLabel; // 星座
@property (nonatomic,strong) UILabel *tagLabel; // 标签
@property (nonatomic,strong) UILabel *autographLabel; // 签名

@end
@implementation HelpGirlView
#pragma mark - 头像
- (UIImageView *)iconImageView {
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.image = [UIImage imageNamed:@"xq_bigtx_dy"];
        _iconImageView.contentMode = UIViewContentModeScaleAspectFill;
        _iconImageView.clipsToBounds = YES;
        [self addSubview:_iconImageView];
    }
    return _iconImageView;
}

#pragma mark - 昵称
- (UILabel *)nickLabel {
    if (!_nickLabel) {
        _nickLabel = [[UILabel alloc] init];
        _nickLabel.font = [UIFont systemFontOfSize:14];
        [_nickLabel setTextColor:HEXCOLOR(0x333333)];
        [self addSubview:_nickLabel];
    }
    return _nickLabel;
}

#pragma mark - 星座
- (UILabel *)constellationLabel {
    if (!_constellationLabel) {
        _constellationLabel = [[UILabel alloc] init];
        _constellationLabel.font = [UIFont systemFontOfSize:11];
        [_constellationLabel setTextColor:HEXCOLOR(0x999999)];
        [self addSubview:_constellationLabel];
    }
    return _constellationLabel;
}

#pragma mark - 标签
- (UILabel *)tagLabel {
    if (!_tagLabel) {
        _tagLabel = [[UILabel alloc] init];
        _tagLabel.font = [UIFont systemFontOfSize:11];
        _tagLabel.numberOfLines = 0;
        [_tagLabel setTextColor:HEXCOLOR(0x999999)];
        [self addSubview:_tagLabel];
    }
    return _tagLabel;
}

#pragma mark - 签名
- (UILabel *)autographLabel {
    if (!_autographLabel) {
        _autographLabel = [[UILabel alloc] init];
        _autographLabel.numberOfLines = 0;
        _autographLabel.font = [UIFont systemFontOfSize:11];
        [_autographLabel setTextColor:HEXCOLOR(0x999999)];
        [self addSubview:_autographLabel];
    }
    return _autographLabel;
}

+ (instancetype)showHelpGirlAddedTo:(UIView *)view ViewModel:(HelpGirlViewModel *)model {
    
    HelpGirlView *HGView = nil;
    
    if (oldView) {
        HGView = oldView;
    } else {
        HGView = [[HelpGirlView alloc] init];
    }
    HGView.frame = model.rect;
    [HGView setNeedsDisplay];
    HGView.model = model;
    
    [HGView updateContentWithModel:model];
    
    if (!view) {
        view = [[UIApplication sharedApplication] keyWindow];
    }
    
    for (UIView *v in view.subviews) {
        if ([v isKindOfClass:[HelpGirlView class]]) {
            [v removeFromSuperview];
        }
    }
    
    [view addSubview:HGView];
    
    //动画效果弹出
    CGRect frame = model.rect;
    
    if (oldView) {
        HGView.frame = oldView.frame;
    } else {
        HGView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, frame.origin.y, 0, frame.size.height);
    }
    [UIView animateWithDuration:0.5 animations:^{
        HGView.frame = frame;
    } completion:^(BOOL finished) {
        oldView = HGView;
    }];
    
    return HGView;
}


- (void)updateContentWithModel:(HelpGirlViewModel *)model {
    if (!model) {
        model = [[HelpGirlViewModel alloc] init];
    }
    
    CGRect rect = model.rect;
    
    if (model.triangleHeight <= 0) {
        model.triangleHeight = 10;
    }
    
    if (model.startX < model.triangleHeight/2) {
        model.startX = rect.size.width / 2;
    }
    
    if (model.radius <= 0) {
        model.radius = rect.size.height * 0.1;
    }
    
    self.backgroundColor = [UIColor clearColor];
    
    UIEdgeInsets insets = model.insets;
    CGFloat width = rect.size.width; // 绘制宽高 *
    CGFloat height = rect.size.height;
    CGFloat triangleHeight = model.triangleHeight; // 三角形高度 *
    
    //        [self.iconImageView sd_setImageWithURL:[NSURL URLWithString:model.iconUrl] placeholderImage:[UIImage imageNamed:@"default_img_common"]];
    self.nickLabel.text = model.nick ?:@"";
    self.constellationLabel.text = model.constellation ?: @"";
    self.tagLabel.text = model.tag ?: @"";
    self.autographLabel.text = [NSString stringWithFormat:@"签名：%@",model.autograph?:@""];
    
    // 内部上下间距都为8,左右间距都为5
    self.iconImageView.frame = CGRectMake(5 + insets.left, insets.top + triangleHeight +  8, height - insets.top - insets.bottom - triangleHeight - 8 * 2, height - insets.top - insets.bottom - triangleHeight - 8 * 2);
    self.nickLabel.frame = CGRectMake(CGRectGetMaxX(self.iconImageView.frame) + 10, CGRectGetMinY(self.iconImageView.frame), width-CGRectGetWidth(self.iconImageView.frame)-insets.left-insets.right-20, 20);
    self.constellationLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.nickLabel.frame) + 6, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.constellationLabel]);
    self.tagLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.constellationLabel.frame) + 6, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.tagLabel]);
    self.autographLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.tagLabel.frame) + 6, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.autographLabel]);
    
    if(CGRectGetMaxY(self.autographLabel.frame) > CGRectGetMaxY(self.iconImageView.frame) + 8)
    {
        // 计算单行高度
        CGFloat singleHeight = [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.tagLabel];
        // 超出的高度
        CGFloat moreHeight = CGRectGetMaxY(self.autographLabel.frame) - (CGRectGetMaxY(self.iconImageView.frame) + 8);
        
        CGRect tempRect = self.autographLabel.frame;
        
        if ((int)moreHeight % (int)singleHeight == 0) {
            self.autographLabel.frame = CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width, tempRect.size.height - moreHeight);
        } else {
            self.autographLabel.frame = CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width, tempRect.size.height - ((int)moreHeight/(int)singleHeight + 1) * singleHeight);
        }
    }
}

#pragma mark - 计算字符的高度

- (CGFloat)yj_CalculateContentHeightWithWidth:(CGFloat)width
                                        label:(UILabel *)label {
    
    NSDictionary * tdic = [NSDictionary dictionaryWithObjectsAndKeys:label.font,NSFontAttributeName,nil];
    CGSize actualsize;
    if (label.numberOfLines == 0) {
        actualsize = [label.text boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:tdic context:nil].size;
    } else {
        CGSize tempSize = [@"单行" boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:tdic context:nil].size;
        actualsize = CGSizeMake(tempSize.width, tempSize.height * label.numberOfLines);
    }
    
    return actualsize.height;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    UIEdgeInsets insets = self.model.insets; // 上下左右绘制间距
    CGFloat width = rect.size.width; // 绘制宽高
    CGFloat height = rect.size.height;
    CGFloat radius = self.model.radius;
    (width + height) * 0.05; // 圆角大小
    CGFloat triangleHeight = self.model.triangleHeight; // 三角形高度
    UIColor *bgColor = self.model.bgColor ?: [UIColor whiteColor]; // 填充的背景颜色
    UIColor *lineColor = self.model.lineColor ?: HEXCOLOR(0xffd302); // 边框颜色
    CGFloat startX = self.model.startX; // 三角形定点位置
    
    //拿到当前视图准备好的画板
    CGContextRef context = UIGraphicsGetCurrentContext();
    //利用path进行绘制三角形
    CGContextBeginPath(context);//标记
    
    CGFloat startY = insets.top;
    CGContextMoveToPoint(context, startX, startY);//设置起点
    
    CGContextAddLineToPoint(context, startX + triangleHeight / sqrt(3), startY + triangleHeight); // 三角右边线
    
    if (startX + triangleHeight >= width - insets.right - radius) {
        CGFloat rightStartAngle = angleBetweenLines(CGPointMake(startX + triangleHeight * sqrt(3), startY + triangleHeight), CGPointMake(width - radius - insets.right, radius + triangleHeight + startY), CGPointMake(width - insets.right, insets.bottom + triangleHeight + radius), CGPointMake(width - radius - insets.right, radius + triangleHeight + startY));
        
        // 右上角圆角
        CGContextAddArc(context, width - radius - insets.right, radius + triangleHeight + startY, radius, - rightStartAngle / 180 * M_PI, 0.0, 0);
    } else {
        // 右水平线
        CGContextAddLineToPoint(context, width - insets.right - radius, startY + triangleHeight);
        // 右上角圆角
        CGContextAddArc(context, width - radius - insets.right, radius + triangleHeight + startY, radius, -0.5 * M_PI, 0.0, 0);
    }
    
    
    
    
    // 右垂直线和右下角圆角
    CGContextAddLineToPoint(context, width - insets.right, height - insets.bottom - radius);
    CGContextAddArc(context, width - radius - insets.right, height - radius - insets.bottom, radius, 0.0, 0.5 * M_PI, 0);
    
    // 底部水平线和左下角圆角
    CGContextAddLineToPoint(context, insets.left + radius, height - insets.bottom);
    CGContextAddArc(context, radius + insets.left, height - radius - insets.bottom, radius, 0.5 * M_PI, M_PI, 0);
    
    // 左上角圆角和左垂直线
    CGContextAddLineToPoint(context, insets.left , startY + triangleHeight + radius);
    CGContextAddArc(context, radius + insets.left, radius + triangleHeight + startY, radius, M_PI, 1.5 * M_PI, 0);
    
    
    CGContextAddLineToPoint(context, startX - triangleHeight / sqrt(3), startY + triangleHeight); // 三角左边线
    
    CGContextClosePath(context);//路径结束标志
    
    [bgColor setFill];//设置填充色
    [lineColor setStroke];
    
    CGContextDrawPath(context, kCGPathFillStroke);//绘制路径path
}



- (void)dismissWithFrom:(UIView *)view{
    
    if (!view) {
        view = [[UIApplication sharedApplication] keyWindow];
    }
    
    for (UIView *v in view.subviews) {
        if ([v isKindOfClass:[HelpGirlView class]]) {
            [v removeFromSuperview];
        }
    }
    
    //动画效果淡出
    [UIView animateWithDuration:0.5 animations:^{
        oldView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, oldView.frame.origin.y, oldView.frame.size.width, oldView.frame.size.height);
    } completion:^(BOOL finished) {
        if (finished) {
            [oldView removeFromSuperview];
            oldView = nil;
        }
    }];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    if (![touch.view isEqual:self]) {
        [self dismissWithFrom:nil];
    }
}


@end

@implementation HelpGirlViewModel
@end
