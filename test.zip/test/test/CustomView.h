//
//  CustomView.h
//  test
//
//  Created by 冯垚杰 on 2017/3/12.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomViewModel;

@interface CustomView : UIView

@property (nonatomic,strong) CustomViewModel *customViewModel;

- (instancetype)initWithFrame:(CGRect)frame CustomViewModel:(CustomViewModel *)model;

@end


@interface CustomViewModel : NSObject

/** 图片url */
@property (nonatomic,copy) NSString *iconUrl; 
/** 昵称 */
@property (nonatomic,copy) NSString *nick; 
/** 签名 */
@property (nonatomic,copy) NSString *autograph; 
/** 标签 */
@property (nonatomic,copy) NSString *tag; 
/** 星座 */
@property (nonatomic,copy) NSString *constellation; 

/** 三角形定点x位置 默认为中点 赋值时为当前界面的x坐标-本view的x坐标*/
@property (nonatomic, assign) CGFloat startX; 
/** 上下左右绘制间距 默认0 */
@property (nonatomic, assign) UIEdgeInsets insets; 
/** 圆角大小  默认高度的0.1倍 */
@property (nonatomic, assign) CGFloat radius; 
/** 三角形高度 默认10 */
@property (nonatomic, assign) CGFloat triangleHeight; 
/** 填充的背景颜色 默认白色 */
@property (nonatomic,strong) UIColor *bgColor; 
/** 边框颜色 默认桔红色 */
@property (nonatomic,strong) UIColor *lineColor; 

@end
