//
//  CustomView.m
//  test
//
//  Created by 冯垚杰 on 2017/3/12.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import "CustomView.h"


@interface CustomView ()

@property (nonatomic,strong) UIImageView *iconImageView;  // 人物图片
@property (nonatomic,strong) UILabel *nickLabel; // 昵称
@property (nonatomic,strong) UILabel *constellationLabel; // 星座
@property (nonatomic,strong) UILabel *tagLabel; // 标签
@property (nonatomic,strong) UILabel *autographLabel; // 签名

@end
@implementation CustomView

- (UIImageView *)iconImageView {
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.backgroundColor = [UIColor greenColor];
        [self addSubview:_iconImageView];
    }
    return _iconImageView;
}

- (UILabel *)nickLabel {
    if (!_nickLabel) {
        _nickLabel = [[UILabel alloc] init];
        _nickLabel.font = [UIFont systemFontOfSize:14];
        _nickLabel.text = @"关关";
        _nickLabel.backgroundColor = [UIColor greenColor];
        [self addSubview:_nickLabel];
    }
    return _nickLabel;
}

- (UILabel *)constellationLabel {
    if (!_constellationLabel) {
        _constellationLabel = [[UILabel alloc] init];
        _constellationLabel.font = [UIFont systemFontOfSize:11];
        _constellationLabel.text = @"白羊座";
        _constellationLabel.backgroundColor = [UIColor greenColor];
        [self addSubview:_constellationLabel];
    }
    return _constellationLabel;
}
- (UILabel *)tagLabel {
    if (!_tagLabel) {
        _tagLabel = [[UILabel alloc] init];
        _tagLabel.font = [UIFont systemFontOfSize:11];
        _tagLabel.numberOfLines = 0;
        _tagLabel.text = @"学霸、吃货、情感专家";
        _tagLabel.backgroundColor = [UIColor greenColor];
        [self addSubview:_tagLabel];
    }
    return _tagLabel;
}

- (UILabel *)autographLabel {
    if (!_autographLabel) {
        _autographLabel = [[UILabel alloc] init];
        _autographLabel.numberOfLines = 0;
        _autographLabel.text = @"签名:有爱要勇敢的说出来有爱要勇敢的说出来有爱要勇敢的说出来有爱要勇敢的说出来";
        _autographLabel.font = [UIFont systemFontOfSize:11];
        _autographLabel.backgroundColor = [UIColor greenColor];
        [self addSubview:_autographLabel];
    }
    return _autographLabel;
}



- (instancetype)initWithFrame:(CGRect)frame CustomViewModel:(CustomViewModel *)model
{
    self = [super initWithFrame:frame];
    if (self) {
        
        if (!model) {
            model = [[CustomViewModel alloc] init];
        }
        
        if (model.triangleHeight <= 0) {
            model.triangleHeight = 10;
        }
        
        if (model.startX < model.triangleHeight/2) {
            model.startX = frame.size.width / 2;
        }
        
        if (model.radius <= 0) {
            model.radius = frame.size.height * 0.1;
        }
        
        self.customViewModel = model;
        
        self.backgroundColor = [UIColor clearColor];
        CGRect rect = frame;
        UIEdgeInsets insets = model.insets;
        CGFloat width = rect.size.width; // 绘制宽高 *
        CGFloat height = rect.size.height;
        CGFloat triangleHeight = model.triangleHeight; // 三角形高度 *

//        self.iconImageView.image
        self.nickLabel.text = model.nick ?: @"关关";
        self.constellationLabel.text = model.constellation ?: @"白羊座";
        self.tagLabel.text = model.tag ?: @"学霸、吃货、情感专家";
        self.autographLabel.text = model.autograph ?: @"签名:有爱要勇敢的说出来有爱要勇敢的说出来有爱要勇敢的说出来有爱要勇敢的说出来";
        
        // 内部上下间距都为8,左右间距都为5
        self.iconImageView.frame = CGRectMake(5, insets.top + triangleHeight +  8, (width - insets.left - insets.right) / 2 - 5 - triangleHeight / 2, height - insets.top - insets.bottom - triangleHeight - 8 * 2);
        self.nickLabel.frame = CGRectMake(CGRectGetMaxX(self.iconImageView.frame) + 10, CGRectGetMinY(self.iconImageView.frame), CGRectGetWidth(self.iconImageView.frame), 20);
        self.constellationLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.nickLabel.frame) + 8, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.constellationLabel]);
        self.tagLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.constellationLabel.frame) + 8, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.tagLabel]);
        self.autographLabel.frame = CGRectMake(CGRectGetMinX(self.nickLabel.frame), CGRectGetMaxY(self.tagLabel.frame) + 8, CGRectGetWidth(self.nickLabel.frame), [self yj_CalculateContentHeightWithWidth:CGRectGetWidth(self.nickLabel.frame) label:self.autographLabel]);
        
        
    }
    return self;
}

#pragma mark - 计算字符的高度

- (CGFloat)yj_CalculateContentHeightWithWidth:(CGFloat)width
                                        label:(UILabel *)label{
    NSDictionary * tdic = [NSDictionary dictionaryWithObjectsAndKeys:label.font,NSFontAttributeName,nil];
    CGSize actualsize = [label.text boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:tdic context:nil].size;
    
    return actualsize.height;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    UIEdgeInsets insets = self.customViewModel.insets; // 上下左右绘制间距
    CGFloat width = rect.size.width; // 绘制宽高
    CGFloat height = rect.size.height;
    CGFloat radius = self.customViewModel.radius;
    (width + height) * 0.05; // 圆角大小
    CGFloat triangleHeight = self.customViewModel.triangleHeight; // 三角形高度
    UIColor *bgColor = self.customViewModel.bgColor ?: [UIColor whiteColor]; // 填充的背景颜色
    UIColor *lineColor = self.customViewModel.lineColor ?: [UIColor redColor]; // 边框颜色
    CGFloat startX = self.customViewModel.startX; // 三角形定点位置
    
    //拿到当前视图准备好的画板
    CGContextRef context = UIGraphicsGetCurrentContext();
    //利用path进行绘制三角形
    CGContextBeginPath(context);//标记
    
    CGFloat startY = insets.top;
    CGContextMoveToPoint(context, startX, startY);//设置起点
    
    CGContextAddLineToPoint(context, startX + triangleHeight, startY + triangleHeight); // 三角右边线
    
    // 右上角圆角和右水平线
    CGContextAddLineToPoint(context, width - insets.right - radius, startY + triangleHeight);
    CGContextAddArc(context, width - radius - insets.right, radius + triangleHeight + startY, radius, -0.5 * M_PI, 0.0, 0);

    // 右垂直线和右下角圆角
    CGContextAddLineToPoint(context, width - insets.right, height - insets.bottom - radius);
    CGContextAddArc(context, width - radius - insets.right, height - radius - insets.bottom, radius, 0.0, 0.5 * M_PI, 0);
    
    // 底部水平线和左下角圆角
    CGContextAddLineToPoint(context, insets.left + radius, height - insets.bottom);
    CGContextAddArc(context, radius + insets.left, height - radius - insets.bottom, radius, 0.5 * M_PI, M_PI, 0);
    
    // 左上角圆角和左垂直线
    CGContextAddLineToPoint(context, insets.left , startY + triangleHeight + radius);
    CGContextAddArc(context, radius + insets.left, radius + triangleHeight + startY, radius, M_PI, 1.5 * M_PI, 0);
    
    
    CGContextAddLineToPoint(context, startX - triangleHeight, startY + triangleHeight); // 三角左边线
    
    CGContextClosePath(context);//路径结束标志
    
    [bgColor setFill];//设置填充色
    
    
    [lineColor setStroke];
    
    CGContextDrawPath(context, kCGPathFillStroke);//绘制路径path
}





@end

@implementation CustomViewModel
@end
